package com.mylibrary;

import java.util.Scanner;

public class Library_Mngt_System {
	 public static void main(String[] args) {
	        Scanner scan = new Scanner(System.in);
	        Library library = new Library();

	        library.addBook(new Book("The problem fo rupee", "DR.Ambedkar"));
	    	library.addBook(new Book("Lal Salam", "Smriti Irani"));		
	   		library.addBook(new Book("AgniPankhh", "Dr.Kalam"));	 
	   		library.addBook(new Book("The India Story", "Bimal Jalal")); 
	   		library.addBook(new Book("Listen to Your Heart", "	Ruskin Bond"));
	   		library.addBook(new Book("Business of Sports", "Vinit Karnik"));
	   		library.addBook(new Book("A Place Called Home", "Preeti Shenoy")); 
	   		library.addBook(new Book("Modi @20", "VP Venkaiah Naidu"));
	   		library.addBook(new Book("The Struggle for Police Reforms in India", "Prakash Singh")); 
	   		library.addBook(new Book("INDO-PAK WAR 1971", "Rajnath Singh"));
	   		library.addBook(new Book("Human Anatomy", "Dr.Ashwini K"));

	        int choice;
	        do {
	            System.out.println("Library Management System");
	            System.out.println("-------------------------");
	            System.out.println("1. Display available books");
	            System.out.println("2. Borrow a book");
	            System.out.println("3. Return a book");
	            System.out.println("0. Exit");
	            System.out.print("Enter your choice: ");
	            choice = scan.nextInt();
	            scan.nextLine(); 

	            switch (choice) {
	                case 1:
	                    library.displayAvailableBooks();
	                    break;
	                case 2:
	                    System.out.print("Enter the title of the book you want to borrow: ");
	                    String borrowTitle = scan.nextLine();
	                    library.borrowBook(borrowTitle);
	                    break;
	                case 3:
	                    System.out.print("Enter the title of the book you want to return: ");
	                    String returnTitle = scan.nextLine();
	                    library.returnBook(returnTitle);
	                    break;
	                case 0:
	                    System.out.println("Exiting the program. Goodbye!");
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }
	            System.out.println();
	        } while (choice != 0);

	        scan.close();
	    }
	}

